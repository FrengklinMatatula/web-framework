<?php

class Jurusan_model extends CI_Model
{
    public function getAllJurusan()
    {
        // //menggunakan cara pertama
        // $query = $this->db->get('mahasiswa');
        // return &query->result_array();

        // menggunakan cara cepat methode chaining
        return $this->db->get('jurusan')->result_array();
    }
    
}