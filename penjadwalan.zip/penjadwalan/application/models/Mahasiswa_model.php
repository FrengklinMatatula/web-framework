<?php 

class Mahasiswa_model extends CI_Model {
	public function getAllMahasiwa()
	{
	return 	$this->db->get('mahasiswa')->result_array();
 	
	}
	 // public function tambahdatamhs()
	 // {
	 // 	$data = [
  //           // "nama" => htmlspecialchars($_POST["nama"]), jika tdk mengunakan CI
  //           // //atau cara lain
  //       'kode' =>  $this->input->post('kode'),
  //       'matakuliah' =>  $this->input->post('matakuliah'),
  //       'sks' =>  $this->input->post('sks'),
  //       'semester' =>  $this->input->post('semester'),
  //       'jurusan' =>  $this->input->post('jurusan')
  //           ];
       
  //       $this->db->insert('mahasiswa',$data);
  //       redirect('mahasiswa');
	 // }
	public function getAllJurusan()
    {
        return $this->db->get('jurusan')->result_array();
    }
    //  public function getMahasiswaById($id)
    // {
    //     return $this->db->get_where('mahasiswa', ['id' => $id])->row_array();
    // }




}