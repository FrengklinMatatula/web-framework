<?php 

class Beranda extends CI_Controller {
public function index()
{
	// memanggil data pada folder view
	$data['judul']='Halaman Beranda';
	$this->load->view('templates/header', $data);
	$this->load->view('Beranda/index');
	$this->load->view('templates/footer');

}

   }