<div class="container">
	<div class="row mt-3">
        <div class="col-md-12">

        	 <!-- menaikan di posisi atas -->
   <!-- Button trigger modal -->
<button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#tambahModal">
  Tambah data
</button>

	 <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">Kode</th>
                    <th scope="col">Matakuliah</th>
                    <th scope="col">Sks</th>
                    <th scope="col">Semester</th>
                    <th scope="col">Jurusan</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($mahasiswa as $mhs) : ?>
                    <tr>
                        <th scope="row"><?= $mhs['kode'];?></th>
                        <td><?= $mhs['matakuliah'];?></td>
                        <td><?= $mhs['sks']; ?></td>
                        <td><?= $mhs['semester']; ?></td>
                        <td><?= $mhs['jurusan']; ?></td>
                        <td>
                            <a href="<?= base_url(); ?>mahasiswa/ubah/<?= $mhs['id']; ?>" class="badge badge-pill badge-success">ubah</a>
                            <a href="<?= base_url(); ?>mahasiswa/hapus/<?= $mhs['id']; ?>" class="badge badge-danger float-right" onclick="return confirm('Apakah Anda Yakin');">hapus</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

    <!-- Modal -->


<!-- Modal -->
<div class="modal fade" id="tambahModal" tabindex="-1" aria-labelledby="tambahModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="tambahModalLabel">Tambah data Mahasiswa</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="card-body">
	  <form action="<?= base_url('mahasiswa')?>" method="post">
       <div class="form-group">
	        	<label for="kode">KODE</label>
	        	<input type="text" name="kode" class="form-control" id="kode"> 
	        </div>
        <div class="form-group">
        	<label for="matakuliah">MATA KULIAH</label>
        	<input type="text" name="matakuliah" class="form-control" id="matakuliah"> 
        </div>
        <div class="form-group">
        	<label for="sks">SKS</label>
        	<input type="text" name="sks" class="form-control" id="sks"> 
        </div>
        <div class="form-group">
        	<label for="semester">SEMESTER</label>
        	<input type="text" name="semester" class="form-control" id="semester"> 
        </div>
        <div class="form-group">
        	<label for="jurusan">JURUSAN</label>
        	<select class="form-control" id="jurusan" name="jurusan">
                <option value="">Pilihan</option>
                <?php foreach ($jurusan as $j) : ?>
                 <option><?= $j['namajurusan']; ?></option>
                 <?php endforeach; ?>
            </select>
       </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Tambah</button>
      </div>
  	</form>
    </div>
  </div>
</div>
	<!-- end modal -->